### **Download Burp-Suite.zip file and Extract It.**

### **Steps to Activate in Kali Linux**
> Execute Kali_Linux_Setup.sh file with Sudo as  

    sudo ./Kali_Linux_Setup.sh

### Burp Suite Pro Activation Steps 
    1). Modify License String in Loader window "license to Siddharth Sangwan"
    2). Copy License key from Loader Window and paste in Burp Suite Pro and click Next.
    3). Select Manual Activation Option on your bottom Right in Burp Suite Pro.
    4). Copy License Request from BurpSuite_Pro and paste in Loader.
    5). Copy license response from Loader and paste in Burp Suite Pro, then next and Done.
    6). Now you Burp Suite Pro is Activated you can close all windows and execute it by typing burp in terminal

### **Steps to activate in Windows.**
Open Powershell and execute below command to set Script Execution Policy.

    Set-ExecutionPolicy -ExecutionPolicy bypass -Scope process
    

Now Execute Windows_Setup.ps1 file in Powershell to Complete Installation.

    ./Windows_Setup.ps1

## Burp Suite Pro Activation Steps 
        1). Modify License String in Loader window "license to Siddharth Sangwan"
        2). Copy License key from Loader Window and paste in Burp Suite Pro and click Next.
        3). Select Manual Activation Option on your bottom Right in Burp Suite Pro.
        4). Copy License Request from BurpSuite_Pro and paste in Loader.
        5). Copy license response from Loader and paste in Burp Suite Pro, then next and Done.
        6). For Start Menu Entry, copy **Burp-Suite-Pro.vbs** file to 
                C:\ProgramData\Microsoft\Windows\Start Menu\Programs\